#!/usr/bin/env pybricks-micropython
from pybricks.hubs import EV3Brick
from pybricks.ev3devices import (Motor, TouchSensor, ColorSensor,
                                 InfraredSensor, UltrasonicSensor, GyroSensor)
from pybricks.parameters import Port, Stop, Direction, Button, Color
from pybricks.tools import wait, StopWatch, DataLog
from pybricks.robotics import DriveBase
from pybricks.media.ev3dev import SoundFile, ImageFile

# This program requires LEGO EV3 MicroPython v2.0 or higher.
# Click "Open user guide" on the EV3 extension tab for more information.

#Create DataLog
data = DataLog('time','angle','status', name = "DataAngle",  timestamp = False , extension= 'txt')
data1 = DataLog('status', name = "status",  timestamp = False , extension= 'txt')
# Create your objects here.
ev3 = EV3Brick()
gyro = GyroSensor(Port.S4)  
watch = StopWatch()


# Write your program here.
gyro.reset_angle(0)
while True:
    angle = gyro.angle()
    time = watch.time()
    sat = " "
    print("time/angle/status")
    if angle < 0:
        sat = "down"
        data.log(time,angle,sat)
        data1.log(sat)        
        print(data)
        print(data1)
    elif angle > 0:
        sat = "up"
        data.log(time,angle,sat)
        data1.log(sat)   
        print(data)
        print(data1)
    else: 
         sat = "none" 
         data.log(time,angle,sat)
         data1.log(sat)   
         print(data)
         print(data1)